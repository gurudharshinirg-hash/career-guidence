from django.shortcuts import render,redirect
from django.contrib.auth import login
from .forms import RegisterForm
from .models import Myuser
from django.contrib import messages
def index(request):
    return render(request, 'index.html')
def register(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")

        new_user = Myuser.objects.create(
            username=username, email=email,
            password1=password1, password2=password2
        )
        request.session["username"] = new_user.username
        return redirect("dashboard")

    return render(request, "register.html")


def dashboard(request):
    username = request.session.get("username", "Guest")
    return render(request, "dashboard.html", {"username": username})
def careers(request):
    career_data = {
        "Coding Careers": [
            "Software Developer", "Web Developer", "App Developer", "Data Analyst", "AI Engineer"
        ],
        "Non-Coding Careers": [
            "UI/UX Designer", "Project Manager", "Content Writer", "Digital Marketer", "HR Specialist"
        ],
        "Creative Careers": [
            "Graphic Designer", "Animator", "Video Editor", "Interior Designer", "Game Designer"
        ],
        "Management Careers": [
            "Business Analyst", "Product Manager", "Operations Manager", "Finance Executive", "Sales Manager"
        ],
        "Healthcare Careers": [
            "Doctor", "Nurse", "Pharmacist", "Lab Technician", "Psychologist"
        ],
    }
    return render(request, "careers.html", {"careers": career_data})
def table(request):
    data = Myuser.objects.all()
    return render(request, "admin.html", {'data':data})
def home(request):
    return render(request, 'home.html')
def book(request):
    return render(request,'books.html')
def quiz(request):
    return render(request,'quiz.html')
def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password1 = request.POST.get('password1')

        try:
            user = Myuser.objects.get(username=username, password1=password1)
            request.session['username'] = user.username
            request.session['email'] = user.email
            return redirect('useraccount')
        except Myuser.DoesNotExist:
            messages.error(request, "Invalid username or password.")
            return redirect('login')

    return render(request, 'login.html')

def useraccount(request):
    username = request.session.get('username')
    email = request.session.get('email')
    if not username:
        return redirect('login')
    context = {
        'username': username,
        'email': email,

    }
    return render(request, 'useraccount.html', context)