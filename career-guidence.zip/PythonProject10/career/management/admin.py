from django.contrib import admin
from .models import Myuser  # match your model class

admin.site.register(Myuser)
