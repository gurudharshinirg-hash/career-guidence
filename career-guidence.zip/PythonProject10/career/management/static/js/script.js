// Wait until DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {

    // Example: Button click action
    const startBtn = document.querySelector(".btn-primary");
    if (startBtn) {
        startBtn.addEventListener("click", function () {
            alert("🚀 Welcome! Your Career Counselling Journey Begins...");
            // Later, redirect to quiz page
            // window.location.href = "/quiz/";
        });
    }

    // Example: Simple fade-in animation
    const elements = document.querySelectorAll("h2, p, img");
    elements.forEach((el, index) => {
        el.style.opacity = "0";
        el.style.transition = "opacity 1s ease-in-out";
        setTimeout(() => {
            el.style.opacity = "1";
        }, 300 * index);
    });

});
