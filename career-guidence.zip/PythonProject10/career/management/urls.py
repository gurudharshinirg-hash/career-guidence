from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path("register/", views.register, name="register"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/careers", views.careers, name="careers"),
    path("register/table",views.table,name="table"),
    path("dashboard/home",views.home,name="home"),
    path("dashboard/book",views.book,name="book"),
    path("dashboard/quiz",views.quiz,name="quiz"),
    path("register/login",views.login,name="login"),
    path("useraccount",views.useraccount,name="useraccount")
]
