from django import forms
from django import forms
from .models import Myuser

class RegisterForm(forms.ModelForm):
    class Meta:
        model = Myuser
        fields = ['username', 'email','password1','password2']